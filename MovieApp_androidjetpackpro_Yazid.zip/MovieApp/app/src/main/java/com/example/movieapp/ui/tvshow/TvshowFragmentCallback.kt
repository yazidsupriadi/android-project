package com.example.movieapp.ui.tvshow
import com.example.movieapp.data.DataEntity
interface TvshowFragmentCallback {

    fun onShareClick(course: DataEntity)
}
