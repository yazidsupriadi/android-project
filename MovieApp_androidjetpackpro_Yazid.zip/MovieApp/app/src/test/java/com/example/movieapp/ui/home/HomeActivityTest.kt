package com.example.movieapp.ui.home


import androidx.recyclerview.widget.RecyclerView
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.contrib.RecyclerViewActions
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import com.example.movieapp.R
import com.example.movieapp.utils.DataDummy
import org.junit.Rule
import org.junit.Test


class HomeActivityTest{

    private val dummyMovie = DataDummy.generateDummyMovies()
    private val dummyTvshows = DataDummy.generateDummyTvshows()

    @Rule
    var activityRule = ActivityScenarioRule(HomeActivity::class.java)

    //menampilkan data movie
    // memastikan rv_movie dapat tampil
    // menampilkan seluruh data di rv_movie hingga posisi terakhir
    @Test
    fun loadMovies() {
        onView(withId(R.id.rv_movie)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_movie)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(
                dummyMovie.size
            )
        )
    }

    //menampilkan data tv show
    // memastikan rv_tvshow dapat tampil
    // menampilkan seluruh data di rv_tvshow hingga posisi terakhir
    //klik tab layout dengan teks TV SHOW
    @Test

    fun loadTvshows() {

        onView(withText("TV SHOW")).perform(click())
        onView(withId(R.id.rv_tvshow)).check(matches(isDisplayed()))
        onView(withId(R.id.rv_tvshow)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(dummyTvshows.size))
    }

    //Memberikan tindakan klik pada data pertama di rv_movie
    //Memastikan TextView untuk title tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk description tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk genre tampil sesuai dengan yang diharapkan.
    //Memastikan ImageView untuk imagepath tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk duration tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk rating tampil sesuai dengan yang diharapkan.

    @Test
    fun loadDetailMovie() {

        onView(withId(R.id.rv_movie)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(R.id.movie_name)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_name)).check(matches(withText(dummyMovie[0].title)))
        onView(withId(R.id.detail_description)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_description)).check(matches(withText(dummyMovie[0].description)))
        onView(withId(R.id.detail_genre)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_genre)).check(matches(withText(dummyMovie[0].genre)))
        onView(withId(R.id.detail_director)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_director)).check(matches(withText(dummyMovie[0].director)))
        onView(withId(R.id.img_detail_profile)).check(matches(isDisplayed()))
        onView(withId(R.id.img_detail_profile)).check(matches(withText(dummyMovie[0].imagePath)))
        onView(withId(R.id.detail_runtime)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_runtime)).check(matches(withText(dummyMovie[0].duration)))
        onView(withId(R.id.detail_rating)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_rating)).check(matches(withText(dummyMovie[0].rating)))
    }


    //Memberikan tindakan klik pada data pertama di rv_tvshow
    //Memastikan TextView untuk title tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk description tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk genre tampil sesuai dengan yang diharapkan.
    //Memastikan ImageView untuk imagepath tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk duration tampil sesuai dengan yang diharapkan.
    //Memastikan TextView untuk rating tampil sesuai dengan yang diharapkan.

    @Test
    fun loadDetailTvshow() {

        onView(withId(R.id.rv_tvshow)).perform(RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))
        onView(withId(R.id.movie_name)).check(matches(isDisplayed()))
        onView(withId(R.id.movie_name)).check(matches(withText(dummyTvshows[0].title)))
        onView(withId(R.id.detail_description)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_description)).check(matches(withText(dummyTvshows[0].description)))
        onView(withId(R.id.detail_genre)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_genre)).check(matches(withText(dummyTvshows[0].genre)))
        onView(withId(R.id.detail_director)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_director)).check(matches(withText(dummyTvshows[0].director)))
        onView(withId(R.id.img_detail_profile)).check(matches(isDisplayed()))
        onView(withId(R.id.img_detail_profile)).check(matches(withText(dummyTvshows[0].imagePath)))
        onView(withId(R.id.detail_runtime)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_runtime)).check(matches(withText(dummyTvshows[0].duration)))
        onView(withId(R.id.detail_rating)).check(matches(isDisplayed()))
        onView(withId(R.id.detail_rating)).check(matches(withText(dummyTvshows[0].rating)))
    }

}