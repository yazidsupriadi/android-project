package com.example.indonesianfoodapp

data class Food(var name: String = "",var detail: String = "", var photo: Int = 0) {
}