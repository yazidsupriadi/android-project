package com.example.mygithub

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Github(
    var name: String = "",
    var username: String ="",
    var photo: Int = 0,
    var follower : Int = 0,
    var following : Int = 0,
    var location : String = ""
        ):Parcelable
