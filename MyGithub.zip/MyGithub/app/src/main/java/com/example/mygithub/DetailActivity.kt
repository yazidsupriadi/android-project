package com.example.mygithub

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import de.hdodenhof.circleimageview.CircleImageView

class DetailActivity : AppCompatActivity() {
    companion object {
        const val EXTRA_GITHUB = "extra_github"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)


        val tvName:TextView = findViewById(R.id.tv_github_name)
        val tvUsername:TextView = findViewById(R.id.tv_github_username)
        val tvFollower:TextView = findViewById(R.id.tv_github_follower)
        val tvFollowing:TextView = findViewById(R.id.tv_github_following)
        val tvLocation:TextView = findViewById(R.id.tv_github_location)

        val ivDataImage: CircleImageView = findViewById(R.id.iv_github_photo)

        val github = intent.getParcelableExtra<Github>(EXTRA_GITHUB) as Github
        tvName.text = github.name
        tvUsername.text = github.username
        tvFollower.text = github.follower.toString()
        tvFollowing.text = github.following.toString()
        tvLocation.text = github.location

        val bundle = intent.extras
        if (bundle != null) {
            ivDataImage.setImageResource(github.photo)
        }

    }
}