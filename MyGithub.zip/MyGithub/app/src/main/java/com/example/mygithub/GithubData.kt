package com.example.mygithub

object GithubData {
    private val githubNames = arrayOf(
            "Aditya Fitriadi",
            "Auzan Assidqi",
            "Muhammad Yazid Supriadi",
            "Huda Izzatul Haq",
            "Wishnutama",
            "Nadiem Makariem",
            "Sundar Pichai",
            "Jan Koum",
            "Mark Zuckenberg",
            "Bill Gates",
            "Ahmad Zaki",
            "Wiliam Tanuwijaya"


    )
    private val githubUsernames = arrayOf(
        "@featriadi",
        "@Auzanassqi",
        "@yazidsupriadi",
        "@hudaizzhaq",
        "@Wishnutama",
        "@nadiemmakariem",
        "@sundarpichai",
        "@jankoum",
        "@markzuckenberg",
        "@billgates",
        "@ahmadzaky",
        "@williamtanuwijaya"


    )
    private val githubFollower = intArrayOf(
        60,
        70,
        50,
        60,
        100,
        100,
        200,
        200,
        500,
        500,
        100,
        100

    )

    private val githubFollowing = intArrayOf(
        40,
        30,
        30,
        30,
        10,
        15,
        20,
        20,
        5,
        5,
        20,
        20


    )
    private val githubLocation = arrayOf(
        "Depok, Indonesia",
        "Jakarta, Indonesia",
        "Depok, Indonesia",
        "Jakarta, Indonesia",
        "Bandung, Indonesia",
        "Tanggerang, Indonesia",
        "Silicon Valley, USA",
        "New York, USA",
        "Los Angeles, USA",
        "Arizona, USA",
        "Depok, Indonesia",
        "Jakarta, Indonesia"


    )


    private val githubPhotos = intArrayOf(
        R.drawable.adit,
        R.drawable.auzan,
        R.drawable.yazid,
        R.drawable.huda,
        R.drawable.wisnutama,
        R.drawable.nadiem_makarim,
        R.drawable.sundar_pichai,
        R.drawable.jan_koum,
        R.drawable.mark_zuckernberg,
        R.drawable.bill_gates,
        R.drawable.ahmad_zaki,
        R.drawable.willian_tanuwijaya
    )

    val listData: ArrayList<Github>
        get() {
            val list = arrayListOf<Github>()
            for (position in githubNames.indices) {
                val github = Github()
                github.name = githubNames[position]
                github.username = githubUsernames[position]
                github.photo = githubPhotos[position]
                github.follower = githubFollower[position]
                github.following = githubFollowing[position]
                github.location = githubLocation[position]

                list.add(github)
            }
            return list
        }
}